# 📱 UPLOAD FILES LÊN GITHUB TỪ ĐIỆN THOẠI

## 🎯 CÓ GÌ TRONG FILE ZIP?

### **Frontend Zip:**
```
masterchef-frontend-files/
├── package.json
├── .gitignore
├── public/
│   └── index.html
└── src/
    └── App.jsx
```

### **Backend Zip:**
```
masterchef-backend-files/
├── package.json
├── .gitignore
├── backend-server.js
└── payment-service.js
```

---

## 📥 BƯỚC 1: GIẢI NÉN FILE ZIP

### Trên iPhone:
```
1. Mở Files app
2. Tìm file .zip
3. Tap vào → tự extract
4. Xem folder vừa giải nén
```

### Trên Android:
```
1. Mở Files app (hoặc ES File Explorer)
2. Tìm file .zip
3. Long-press → "Extract"
4. Xem folder vừa giải nén
```

---

## 🌐 BƯỚC 2: TẠO GITHUB REPO (FRONTEND)

```
1. Mở GitHub.com trên browser điện thoại
2. Đăng nhập tài khoản GitHub
3. Click "+" (góc trên cùng) → "New repository"
4. Repository name: masterchef-frontend
5. Description: Restaurant Website Frontend
6. Chọn: Public ✅
7. Click "Create repository"

✅ Repo tạo xong!
```

---

## 📤 BƯỚC 3: UPLOAD FRONTEND FILES

### Cách 1: DÙNG GITHUB WEB (DỄ NHẤT)

```
1. Vào repo: masterchef-frontend
2. Click "Add file" → "Upload files"
3. Chọn files từ phone (từ folder giải nén)
4. Upload:
   ✅ package.json
   ✅ .gitignore
   ✅ public/index.html
   ✅ src/App.jsx

5. Mỗi file click:
   "Add file" → "Upload files"
   → Chọn file
   → "Commit changes"
```

### Cách 2: KÉO THẢ (NẾU BROWSER HỖ TRỢ)

```
1. Vào repo: masterchef-frontend
2. Click "Add file" → "Upload files"
3. Kéo thả files từ folder
4. Tự động upload
5. Commit
```

---

## 📋 UPLOAD CHECKLIST (FRONTEND)

```
Cấu trúc sau khi upload:

masterchef-frontend/
├── package.json           ✅
├── .gitignore             ✅
├── public/
│   └── index.html         ✅
└── src/
    └── App.jsx            ✅

(Nếu upload sai cấu trúc, GitHub sẽ tự tạo folders)
```

---

## 🌐 BƯỚC 4: TẠO GITHUB REPO (BACKEND)

```
1. GitHub.com
2. Click "+" → "New repository"
3. Repository name: masterchef-backend
4. Description: Restaurant API Backend
5. Public ✅
6. Create

✅ Backend repo tạo xong!
```

---

## 📤 BƯỚC 5: UPLOAD BACKEND FILES

```
1. Vào repo: masterchef-backend
2. Click "Add file" → "Upload files"
3. Upload files:
   ✅ package.json
   ✅ .gitignore
   ✅ backend-server.js
   ✅ payment-service.js

4. Mỗi file:
   - Click "Add file" → "Upload files"
   - Chọn file từ phone
   - "Commit changes"
```

---

## 📋 UPLOAD CHECKLIST (BACKEND)

```
Cấu trúc sau khi upload:

masterchef-backend/
├── package.json           ✅
├── .gitignore             ✅
├── backend-server.js      ✅
└── payment-service.js     ✅

(Files ở root, không có subfolder)
```

---

## ⏱️ TỔNG THỜI GIAN

```
Extract files:           2 phút
Tạo frontend repo:       2 phút
Upload frontend files:   5 phút
Tạo backend repo:        2 phút
Upload backend files:    5 phút
────────────────────────────
TOTAL:                  16 phút
```

---

## ✅ SAU KHI UPLOAD XONG

```
Bạn có 2 repos trên GitHub:
✅ masterchef-frontend (4 files)
✅ masterchef-backend (4 files)

Tiếp theo:
1. Mở: QUICK_DEPLOY_30MIN.md
2. Deploy frontend to Vercel
3. Deploy backend to Render
4. Setup MongoDB Atlas
5. Website LIVE! 🎉
```

---

## 🆘 NẾU CÓ VẤN ĐỀ

### File không upload được:
```
✅ Thử: Upload từng file một
✅ Thử: Dùng tên đúng (package.json - chữ thường)
✅ Thử: Refresh browser
✅ Thử: Dùng Chrome thay vì Safari
```

### Cấu trúc folder sai:
```
❌ Sai: /src/App.jsx upload → /src/src/App.jsx
✅ Đúng: Upload file trong folder, GitHub tự tạo /src/

Nếu sai:
1. Delete file sai
2. Click file sai
3. "..." → Delete this file
4. Upload lại đúng cấu trúc
```

### Quên upload file:
```
✅ Có thể upload sau
1. Vào repo
2. Click "Add file"
3. Upload file còn lại
4. Xong!
```

---

## 💡 TIPS

### Tip 1: Upload từng file một
- Dễ kiểm tra
- Không bị lỗi

### Tip 2: Xem cấu trúc sau upload
- GitHub hiển thị folder tree
- Verify cấu trúc đúng

### Tip 3: Refresh browser
- Nếu thấy file chưa hiển thị
- Ctrl+R hoặc pull-to-refresh

### Tip 4: Dùng Wi-Fi
- Upload nhanh hơn
- Tránh timeout

---

## 📊 FILE SIZE

```
package.json (Frontend):     ~500 bytes
.gitignore (Frontend):       ~200 bytes
index.html:                  ~500 bytes
App.jsx:                     ~50 KB ⚠️ File lớn
────────────────────────
Frontend Total:              ~51 KB

package.json (Backend):      ~400 bytes
.gitignore (Backend):        ~200 bytes
backend-server.js:           ~15 KB
payment-service.js:          ~10 KB
────────────────────────
Backend Total:               ~25 KB

Grand Total:                 ~76 KB (nhỏ!)
```

---

## 🎉 DONE!

Sau khi upload xong 2 repos:

```
1. Frontend repo: masterchef-frontend ✅
2. Backend repo: masterchef-backend ✅
3. Sẵn sàng deploy ✅

Tiếp theo: QUICK_DEPLOY_30MIN.md
```

---

**Now deploy to Vercel & Render! 🚀**
