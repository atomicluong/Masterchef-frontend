import React, { useState, useEffect } from 'react';
import { ChevronDown, Clock, MapPin, Phone, Mail, Utensils, Train, ShoppingCart, Calendar, Users, AlertCircle, CheckCircle, Loader, ChevronLeft, ChevronRight, X } from 'lucide-react';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const MasterchefWebsite = () => {
  const [activeSection, setActiveSection] = useState('home');
  const [cartItems, setCartItems] = useState([]);
  const [bookingData, setBookingData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    guests: 2,
    notes: ''
  });
  const [orderData, setOrderData] = useState({
    items: [],
    name: '',
    phone: '',
    address: ''
  });
  const [showCart, setShowCart] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState({ booking: false, order: false });
  const [submitError, setSubmitError] = useState({ booking: null, order: null });
  const [isLoading, setIsLoading] = useState({ booking: false, order: false });
  const [trackOrderNumber, setTrackOrderNumber] = useState('');
  const [trackedOrder, setTrackedOrder] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [galleryIndex, setGalleryIndex] = useState(0);

  // ==================== REAL HIGH-QUALITY IMAGES ====================
  // Sources: Pexels, Pixabay, Unsplash (High-res)

  const restaurantGallery = [
    {
      url: 'https://images.pexels.com/photos/1581384/pexels-photo-1581384.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=2',
      caption: 'Không gian bếp hiện đại và sang trọng'
    },
    {
      url: 'https://images.pexels.com/photos/2551632/pexels-photo-2551632.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=2',
      caption: 'Bàn ăn tinh tế được trang trí'
    },
    {
      url: 'https://images.pexels.com/photos/2457284/pexels-photo-2457284.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=2',
      caption: 'Khu vực phục vụ ấm cúng'
    },
    {
      url: 'https://images.pexels.com/photos/1579654/pexels-photo-1579654.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=2',
      caption: 'Không gian nhà hàng lộng lẫy'
    },
    {
      url: 'https://images.pexels.com/photos/2398220/pexels-photo-2398220.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=2',
      caption: 'Nhà hàng sang trọng về đêm'
    },
    {
      url: 'https://images.pexels.com/photos/1995521/pexels-photo-1995521.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=2',
      caption: 'Quầy bar cao cấp'
    }
  ];

  // Ảnh món ăn - Cả Việt Nam lẫn Quốc tế
  const dishImages = {
    // Kiệt tác Masterchef
    1: {
      url: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Lẩu Tôm Hùm - Đặc biệt'
    },
    2: {
      url: 'https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Bánh Canh Cua - Truyền thống'
    },
    3: {
      url: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Lẩu Tôm Bầu - Nước lẩu đặc biệt'
    },
    
    // Miền Bắc
    4: {
      url: 'https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Bánh Tôm Hồ Tây - Giòn rụm'
    },
    5: {
      url: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Gà Nướng Tây Bắc - Thơm lừng'
    },
    6: {
      url: 'https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Nem Cua Bể - Chuẩn vị Hải Phòng'
    },
    
    // Miền Trung
    7: {
      url: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Bánh Bột Lọc Huế - Trong suốt'
    },
    8: {
      url: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Lẩu Thái - Cay nóng'
    },
    9: {
      url: 'https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Nem Cuốn Nha Trang - Tươi mát'
    },
    
    // Miền Nam
    10: {
      url: 'https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Hủ Tiếu Nam Vang - Đậu ngon'
    },
    11: {
      url: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Bún Bò Nam Bộ - Nước dùng thơm'
    },
    12: {
      url: 'https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Bánh Xèo Miền Tây - Giòn rụm'
    },
    
    // Quốc tế
    13: {
      url: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Steak Bò Mỹ - Nướng tuyệt hảo'
    },
    14: {
      url: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Sườn BBQ - Kiểu Mỹ'
    },
    15: {
      url: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&dpr=2',
      caption: 'Tôm Yum - Cay nóng Thái'
    }
  };

  const menuItems = {
    signature: [
      { id: 1, name: 'Lẩu Tôm Hùm', description: 'Lẩu hải sản sang trọng với tôm hùm tươi', price: 450000, category: 'Kiệt tác Masterchef' },
      { id: 2, name: 'Bánh Canh Cua', description: 'Bánh canh truyền thống với cua biển tươi ngon', price: 120000, category: 'Kiệt tác Masterchef' },
      { id: 3, name: 'Lẩu Tôm Bầu', description: 'Nước lẩu đặc biệt từ tôm và bầu non', price: 280000, category: 'Kiệt tác Masterchef' }
    ],
    north: [
      { id: 4, name: 'Bánh Tôm Hồ Tây', description: 'Bánh tôm nổi tiếng Hà Nội, vàng giòn', price: 85000, category: 'Miền Bắc' },
      { id: 5, name: 'Gà Nướng Tây Bắc', description: 'Gà nướng thơm lừng từ Tây Bắc', price: 180000, category: 'Miền Bắc' },
      { id: 6, name: 'Nem Cua Bể Hải Phòng', description: 'Nem cua bề chuẩn vị Hải Phòng', price: 75000, category: 'Miền Bắc' }
    ],
    central: [
      { id: 7, name: 'Bánh Bột Lọc Huế', description: 'Bánh bột lọc trong suốt với nhân tôm thịt', price: 65000, category: 'Miền Trung' },
      { id: 8, name: 'Lẩu Thái', description: 'Lẩu cay nóng với vị thơm của Thái Lan', price: 220000, category: 'Miền Trung' },
      { id: 9, name: 'Nem Cuốn Nha Trang', description: 'Nem cuốn tươi mát với nước chấm đặc biệt', price: 55000, category: 'Miền Trung' }
    ],
    south: [
      { id: 10, name: 'Hủ Tiếu Nam Vang', description: 'Hủ tiếu đậu đặc trưng của miền Nam', price: 95000, category: 'Miền Nam' },
      { id: 11, name: 'Bún Bò Nam Bộ', description: 'Bún bò nước dùng thơm đặc biệt', price: 85000, category: 'Miền Nam' },
      { id: 12, name: 'Bánh Xèo Miền Tây', description: 'Bánh xèo giòn rụm với nhân tươi', price: 75000, category: 'Miền Nam' }
    ],
    international: [
      { id: 13, name: 'Steak Bò Mỹ', description: 'Steak nướng tuyệt hảo mỹ vị', price: 320000, category: 'Khám Phá Thế Giới' },
      { id: 14, name: 'Sườn BBQ', description: 'Sườn nướng kiểu Mỹ với sauce đặc biệt', price: 250000, category: 'Khám Phá Thế Giới' },
      { id: 15, name: 'Tôm Yum', description: 'Tôm cay nóng kiểu Thái Lan', price: 180000, category: 'Khám Phá Thế Giới' }
    ]
  };

  const allMenuItems = Object.values(menuItems).flat();

  const addToCart = (item) => {
    setCartItems([...cartItems, item]);
  };

  const removeFromCart = (index) => {
    setCartItems(cartItems.filter((_, i) => i !== index));
  };

  const handleBookingChange = (e) => {
    const { name, value } = e.target;
    setBookingData({ ...bookingData, [name]: value });
  };

  const handleOrderChange = (e) => {
    const { name, value } = e.target;
    setOrderData({ ...orderData, [name]: value });
  };

  const submitBooking = async (e) => {
    e.preventDefault();
    setIsLoading({ ...isLoading, booking: true });
    setSubmitError({ ...submitError, booking: null });

    try {
      const response = await fetch(`${API_URL}/bookings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bookingData)
      });

      if (!response.ok) {
        throw new Error('Failed to create booking');
      }

      const data = await response.json();
      setSubmitSuccess({ ...submitSuccess, booking: true });
      setBookingData({ name: '', email: '', phone: '', date: '', time: '', guests: 2, notes: '' });
      setTimeout(() => {
        setSubmitSuccess({ ...submitSuccess, booking: false });
      }, 3000);
    } catch (error) {
      setSubmitError({ ...submitError, booking: error.message });
    } finally {
      setIsLoading({ ...isLoading, booking: false });
    }
  };

  const submitOrder = async (e) => {
    e.preventDefault();
    setIsLoading({ ...isLoading, order: true });
    setSubmitError({ ...submitError, order: null });

    try {
      const order = { ...orderData, items: cartItems };
      const response = await fetch(`${API_URL}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(order)
      });

      if (!response.ok) {
        throw new Error('Failed to create order');
      }

      const data = await response.json();
      setSubmitSuccess({ ...submitSuccess, order: true });
      setOrderData({ items: [], name: '', phone: '', address: '' });
      setCartItems([]);
      setShowCart(false);
      setTimeout(() => {
        setSubmitSuccess({ ...submitSuccess, order: false });
      }, 3000);
    } catch (error) {
      setSubmitError({ ...submitError, order: error.message });
    } finally {
      setIsLoading({ ...isLoading, order: false });
    }
  };

  const trackOrder = async (e) => {
    e.preventDefault();
    if (!trackOrderNumber) return;

    try {
      const response = await fetch(`${API_URL}/orders/track/${trackOrderNumber}`);
      if (!response.ok) {
        throw new Error('Order not found');
      }
      const data = await response.json();
      setTrackedOrder(data);
    } catch (error) {
      setSubmitError({ ...submitError, order: error.message });
      setTrackedOrder(null);
    }
  };

  const cartTotal = cartItems.reduce((sum, item) => sum + item.price, 0);

  const getStatusBadge = (status) => {
    const statusMap = {
      pending: { color: 'yellow', text: 'Chờ xác nhận' },
      confirmed: { color: 'blue', text: 'Đã xác nhận' },
      preparing: { color: 'blue', text: 'Đang chuẩn bị' },
      delivering: { color: 'purple', text: 'Đang giao' },
      delivered: { color: 'green', text: 'Đã giao' },
      cancelled: { color: 'red', text: 'Đã hủy' }
    };
    const status_info = statusMap[status] || statusMap.pending;
    return status_info;
  };

  const nextGallery = () => {
    setGalleryIndex((prev) => (prev + 1) % restaurantGallery.length);
  };

  const prevGallery = () => {
    setGalleryIndex((prev) => (prev - 1 + restaurantGallery.length) % restaurantGallery.length);
  };

  // Image Modal
  const ImageModal = ({ image, onClose }) => {
    if (!image) return null;
    return (
      <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={onClose}>
        <div className="relative max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={onClose}
            className="absolute -top-10 right-0 text-white hover:text-amber-400"
          >
            <X className="w-8 h-8" />
          </button>
          <img src={image.url} alt={image.caption} className="w-full h-auto rounded-lg" />
          <p className="text-white text-center mt-4">{image.caption}</p>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white font-sans">
      {/* Decorative gradient background */}
      <div className="fixed inset-0 pointer-events-none opacity-30">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-600 rounded-full blur-3xl"></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-10 sticky top-0 border-b border-amber-400/20 bg-slate-900/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-3">
              <Train className="w-8 h-8 text-amber-400" />
              <h1 className="text-2xl font-bold text-amber-400 tracking-wider">MASTERCHEF</h1>
            </div>
            <div className="hidden md:flex items-center gap-8">
              {['home', 'gallery', 'menu', 'booking', 'order', 'contact'].map(section => (
                <button
                  key={section}
                  onClick={() => setActiveSection(section)}
                  className={`capitalize font-medium transition ${
                    activeSection === section ? 'text-amber-400' : 'text-gray-300 hover:text-amber-400'
                  }`}
                >
                  {section}
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowCart(!showCart)}
              className="relative p-2 text-amber-400 hover:bg-amber-400/10 rounded-lg transition"
            >
              <ShoppingCart className="w-6 h-6" />
              {cartItems.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItems.length}
                </span>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="relative z-10">
        {/* HOME SECTION */}
        {activeSection === 'home' && (
          <section className="min-h-screen flex items-center justify-center px-4 py-20">
            <div className="max-w-4xl text-center">
              <div className="mb-8 animate-fade-in">
                <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-amber-400/10 border border-amber-400/30 mb-8">
                  <Train className="w-5 h-5 text-amber-400" />
                  <span className="text-amber-400 font-medium">Khởi hành hành trình</span>
                </div>
              </div>
              <h2 className="text-6xl md:text-7xl font-bold mb-6 leading-tight">
                Một Hành Trình<br />
                <span className="text-amber-400">Ẩm Thực Vô Tận</span>
              </h2>
              <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto leading-relaxed">
                Khởi hành cùng con tàu Masterchef khám phá tinh hoa ẩm thực Việt Nam từ Miền Bắc, Miền Trung, Miền Nam đến những hương vị quốc tế độc đáo.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => setActiveSection('menu')}
                  className="px-8 py-3 bg-amber-400 text-slate-900 font-bold rounded-lg hover:bg-amber-300 transition"
                >
                  Khám Phá Menu
                </button>
                <button
                  onClick={() => setActiveSection('booking')}
                  className="px-8 py-3 border border-amber-400 text-amber-400 font-bold rounded-lg hover:bg-amber-400/10 transition"
                >
                  Đặt Bàn Ngay
                </button>
              </div>
            </div>
          </section>
        )}

        {/* GALLERY SECTION */}
        {activeSection === 'gallery' && (
          <section className="py-20 px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-5xl font-bold mb-4 text-center">Không Gian Masterchef</h2>
              <p className="text-gray-400 text-center mb-12">Khám phá không gian sang trọng và ấm cúng của nhà hàng</p>

              {/* Main Gallery Carousel */}
              <div className="mb-12 relative group">
                <div className="overflow-hidden rounded-lg">
                  <img
                    src={restaurantGallery[galleryIndex].url}
                    alt={restaurantGallery[galleryIndex].caption}
                    className="w-full h-96 object-cover cursor-pointer hover:opacity-90 transition"
                    onClick={() => setSelectedImage(restaurantGallery[galleryIndex])}
                  />
                </div>
                <p className="text-center text-gray-400 mt-4">{restaurantGallery[galleryIndex].caption}</p>
                
                <button
                  onClick={prevGallery}
                  className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-black/50 hover:bg-black/70 rounded-full transition text-white opacity-0 group-hover:opacity-100"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                  onClick={nextGallery}
                  className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-black/50 hover:bg-black/70 rounded-full transition text-white opacity-0 group-hover:opacity-100"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              </div>

              {/* Thumbnail Gallery */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-16">
                {restaurantGallery.map((image, index) => (
                  <div
                    key={index}
                    onClick={() => setGalleryIndex(index)}
                    className={`cursor-pointer rounded-lg overflow-hidden border-2 transition ${
                      galleryIndex === index ? 'border-amber-400' : 'border-gray-600 hover:border-amber-400/50'
                    }`}
                  >
                    <img
                      src={image.url}
                      alt={image.caption}
                      className="w-full h-24 object-cover hover:scale-110 transition"
                    />
                  </div>
                ))}
              </div>

              {/* Dish Gallery */}
              <div>
                <h3 className="text-4xl font-bold text-amber-400 mb-8">Các Món Ăn Đặc Biệt</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                  {allMenuItems.map(item => (
                    <div
                      key={item.id}
                      className="group relative rounded-lg overflow-hidden cursor-pointer"
                      onClick={() => setSelectedImage(dishImages[item.id])}
                    >
                      <img
                        src={dishImages[item.id]?.url}
                        alt={item.name}
                        className="w-full h-40 object-cover group-hover:scale-110 transition"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition flex items-end p-3">
                        <p className="text-white font-bold text-sm opacity-0 group-hover:opacity-100 transition">
                          {item.name}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* MENU SECTION */}
        {activeSection === 'menu' && (
          <section className="py-20 px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-5xl font-bold mb-4 text-center">Menu Hành Trình</h2>
              <p className="text-gray-400 text-center mb-16">Từng món ăn là một trạm dừng trong hành trình khám phá tinh hoa ẩm thực</p>

              {Object.entries({
                'Kiệt tác Masterchef': menuItems.signature,
                'Miền Bắc': menuItems.north,
                'Miền Trung': menuItems.central,
                'Miền Nam': menuItems.south,
                'Khám Phá Thế Giới': menuItems.international
              }).map(([category, items]) => (
                <div key={category} className="mb-16">
                  <h3 className="text-3xl font-bold text-amber-400 mb-8">{category}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {items.map(item => (
                      <div key={item.id} className="group p-6 rounded-lg bg-slate-800/50 border border-amber-400/20 hover:border-amber-400/50 transition">
                        <div className="mb-3 rounded-lg overflow-hidden h-40 cursor-pointer" onClick={() => setSelectedImage(dishImages[item.id])}>
                          <img
                            src={dishImages[item.id]?.url}
                            alt={item.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition"
                          />
                        </div>
                        <h4 className="text-lg font-bold mb-2">{item.name}</h4>
                        <p className="text-gray-400 text-sm mb-4">{item.description}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-amber-400 font-bold text-lg">{item.price.toLocaleString('vi-VN')}₫</span>
                          <button
                            onClick={() => addToCart(item)}
                            className="px-4 py-2 bg-amber-400/20 text-amber-400 rounded hover:bg-amber-400 hover:text-slate-900 transition font-medium"
                          >
                            Thêm
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* BOOKING SECTION */}
        {activeSection === 'booking' && (
          <section className="py-20 px-4">
            <div className="max-w-2xl mx-auto">
              <h2 className="text-5xl font-bold mb-4 text-center">Đặt Bàn</h2>
              <p className="text-gray-400 text-center mb-12">Đặt chỗ tại Masterchef để tận hưởng hành trình ẩm thực độc đáo</p>

              {submitError.booking && (
                <div className="mb-6 p-4 bg-red-500/20 border border-red-400/50 rounded-lg text-red-400 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <div>{submitError.booking}</div>
                </div>
              )}

              {submitSuccess.booking && (
                <div className="mb-6 p-4 bg-green-500/20 border border-green-400/50 rounded-lg text-green-400 flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <div>✓ Đặt bàn thành công! Chúng tôi sẽ liên hệ bạn sớm.</div>
                </div>
              )}

              <form onSubmit={submitBooking} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <input
                    type="text"
                    name="name"
                    placeholder="Họ và Tên"
                    value={bookingData.name}
                    onChange={handleBookingChange}
                    required
                    className="px-4 py-3 bg-slate-800 border border-amber-400/20 rounded-lg focus:border-amber-400 outline-none"
                  />
                  <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={bookingData.email}
                    onChange={handleBookingChange}
                    required
                    className="px-4 py-3 bg-slate-800 border border-amber-400/20 rounded-lg focus:border-amber-400 outline-none"
                  />
                </div>
                <input
                  type="tel"
                  name="phone"
                  placeholder="Số điện thoại"
                  value={bookingData.phone}
                  onChange={handleBookingChange}
                  required
                  className="w-full px-4 py-3 bg-slate-800 border border-amber-400/20 rounded-lg focus:border-amber-400 outline-none"
                />
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <input
                    type="date"
                    name="date"
                    value={bookingData.date}
                    onChange={handleBookingChange}
                    required
                    className="px-4 py-3 bg-slate-800 border border-amber-400/20 rounded-lg focus:border-amber-400 outline-none"
                  />
                  <input
                    type="time"
                    name="time"
                    value={bookingData.time}
                    onChange={handleBookingChange}
                    required
                    className="px-4 py-3 bg-slate-800 border border-amber-400/20 rounded-lg focus:border-amber-400 outline-none"
                  />
                  <select
                    name="guests"
                    value={bookingData.guests}
                    onChange={handleBookingChange}
                    className="px-4 py-3 bg-slate-800 border border-amber-400/20 rounded-lg focus:border-amber-400 outline-none"
                  >
                    {[...Array(10)].map((_, i) => (
                      <option key={i + 1} value={i + 1}>{i + 1} khách</option>
                    ))}
                  </select>
                </div>
                <textarea
                  name="notes"
                  placeholder="Ghi chú thêm (yêu cầu đặc biệt, số bàn yêu thích...)"
                  value={bookingData.notes}
                  onChange={handleBookingChange}
                  rows="4"
                  className="w-full px-4 py-3 bg-slate-800 border border-amber-400/20 rounded-lg focus:border-amber-400 outline-none"
                ></textarea>
                <button
                  type="submit"
                  disabled={isLoading.booking}
                  className="w-full px-6 py-3 bg-amber-400 text-slate-900 font-bold rounded-lg hover:bg-amber-300 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isLoading.booking ? (
                    <>
                      <Loader className="w-5 h-5 animate-spin" />
                      Đang xử lý...
                    </>
                  ) : (
                    'Xác Nhận Đặt Bàn'
                  )}
                </button>
              </form>

              <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-6 rounded-lg bg-slate-800/50 border border-amber-400/20">
                  <MapPin className="w-6 h-6 text-amber-400 mb-3" />
                  <h3 className="font-bold mb-2">Địa điểm</h3>
                  <p className="text-gray-400 text-sm">59 Trúc Bạch, Hà Nội</p>
                  <p className="text-gray-400 text-sm">97 Trịnh Khả, Thanh Hóa</p>
                </div>
                <div className="p-6 rounded-lg bg-slate-800/50 border border-amber-400/20">
                  <Clock className="w-6 h-6 text-amber-400 mb-3" />
                  <h3 className="font-bold mb-2">Giờ Mở Cửa</h3>
                  <p className="text-gray-400 text-sm">10:30 - 23:00 (Hàng ngày)</p>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* ORDER SECTION */}
        {activeSection === 'order' && (
          <section className="py-20 px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-5xl font-bold mb-4 text-center">Đặt Hàng Delivery</h2>
              <p className="text-gray-400 text-center mb-12">Thưởng thức hương vị Masterchef tại nhà</p>

              {/* Track Order Section */}
              <div className="mb-12 p-6 rounded-lg bg-slate-800/50 border border-amber-400/20">
                <h3 className="text-2xl font-bold mb-4">Theo dõi đơn hàng</h3>
                <form onSubmit={trackOrder} className="flex gap-4 mb-4">
                  <input
                    type="text"
                    placeholder="Nhập mã đơn hàng (ví dụ: ORD-1234567890)"
                    value={trackOrderNumber}
                    onChange={(e) => setTrackOrderNumber(e.target.value)}
                    className="flex-1 px-4 py-2 bg-slate-700 border border-amber-400/20 rounded-lg focus:border-amber-400 outline-none"
                  />
                  <button
                    type="submit"
                    className="px-6 py-2 bg-amber-400 text-slate-900 font-bold rounded-lg hover:bg-amber-300 transition"
                  >
                    Tìm kiếm
                  </button>
                </form>

                {trackedOrder && (
                  <div className="p-4 bg-slate-700/50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-bold">Mã đơn:</span>
                      <span>{trackedOrder.orderNumber}</span>
                    </div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-bold">Trạng thái:</span>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium bg-${getStatusBadge(trackedOrder.status).color}-500/20 text-${getStatusBadge(trackedOrder.status).color}-400`}>
                        {getStatusBadge(trackedOrder.status).text}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold">Tổng tiền:</span>
                      <span className="text-amber-400">{trackedOrder.total.toLocaleString('vi-VN')}₫</span>
                    </div>
                  </div>
                )}
              </div>

              {submitError.order && (
                <div className="mb-6 p-4 bg-red-500/20 border border-red-400/50 rounded-lg text-red-400 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <div>{submitError.order}</div>
                </div>
              )}

              {submitSuccess.order && (
                <div className="mb-6 p-4 bg-green-500/20 border border-green-400/50 rounded-lg text-green-400 flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <div>✓ Đặt hàng thành công! Đơn hàng sẽ được giao trong 30-45 phút.</div>
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Menu Items */}
                <div className="lg:col-span-2">
                  <div className="space-y-4">
                    {allMenuItems.map(item => (
                      <div key={item.id} className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50 border border-amber-400/20">
                        <div className="flex-1">
                          <h4 className="font-bold">{item.name}</h4>
                          <p className="text-gray-400 text-sm">{item.description}</p>
                          <p className="text-amber-400 font-bold mt-1">{item.price.toLocaleString('vi-VN')}₫</p>
                        </div>
                        <button
                          onClick={() => addToCart(item)}
                          className="ml-4 px-4 py-2 bg-amber-400/20 text-amber-400 rounded hover:bg-amber-400 hover:text-slate-900 transition font-medium"
                        >
                          +
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Order Form */}
                <div>
                  <div className="sticky top-24 p-6 rounded-lg bg-slate-800/50 border border-amber-400/20">
                    <h3 className="text-xl font-bold mb-4">Đơn Hàng ({cartItems.length})</h3>
                    <div className="space-y-3 mb-6 max-h-64 overflow-y-auto">
                      {cartItems.length === 0 ? (
                        <p className="text-gray-400 text-sm">Chưa có món nào</p>
                      ) : (
                        cartItems.map((item, i) => (
                          <div key={i} className="flex justify-between items-center text-sm">
                            <span>{item.name}</span>
                            <button
                              onClick={() => removeFromCart(i)}
                              className="text-red-400 hover:text-red-300"
                            >
                              ✕
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                    <div className="border-t border-amber-400/20 pt-4 mb-6">
                      <div className="flex justify-between mb-4">
                        <span>Tổng cộng:</span>
                        <span className="text-amber-400 font-bold text-lg">
                          {cartTotal.toLocaleString('vi-VN')}₫
                        </span>
                      </div>
                    </div>

                    {cartItems.length > 0 && (
                      <form onSubmit={submitOrder} className="space-y-4">
                        <input
                          type="text"
                          name="name"
                          placeholder="Tên của bạn"
                          value={orderData.name}
                          onChange={handleOrderChange}
                          required
                          className="w-full px-3 py-2 bg-slate-700 border border-amber-400/20 rounded focus:border-amber-400 outline-none text-sm"
                        />
                        <input
                          type="tel"
                          name="phone"
                          placeholder="Số điện thoại"
                          value={orderData.phone}
                          onChange={handleOrderChange}
                          required
                          className="w-full px-3 py-2 bg-slate-700 border border-amber-400/20 rounded focus:border-amber-400 outline-none text-sm"
                        />
                        <textarea
                          name="address"
                          placeholder="Địa chỉ giao hàng"
                          value={orderData.address}
                          onChange={handleOrderChange}
                          required
                          rows="3"
                          className="w-full px-3 py-2 bg-slate-700 border border-amber-400/20 rounded focus:border-amber-400 outline-none text-sm"
                        ></textarea>
                        <button
                          type="submit"
                          disabled={isLoading.order}
                          className="w-full px-4 py-3 bg-amber-400 text-slate-900 font-bold rounded hover:bg-amber-300 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                        >
                          {isLoading.order ? (
                            <>
                              <Loader className="w-5 h-5 animate-spin" />
                              Đang xử lý...
                            </>
                          ) : (
                            'Đặt Hàng Ngay'
                          )}
                        </button>
                      </form>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* CONTACT SECTION */}
        {activeSection === 'contact' && (
          <section className="py-20 px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-5xl font-bold mb-4 text-center">Liên Hệ</h2>
              <p className="text-gray-400 text-center mb-12">Chúng tôi luôn sẵn sàng phục vụ bạn</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                <div className="p-8 rounded-lg bg-slate-800/50 border border-amber-400/20">
                  <MapPin className="w-8 h-8 text-amber-400 mb-4" />
                  <h3 className="text-2xl font-bold mb-4">Địa Chỉ</h3>
                  <p className="text-gray-300 mb-4">
                    <strong>Hà Nội:</strong><br />
                    59 Trúc Bạch, Hoàn Kiếm, Hà Nội
                  </p>
                  <p className="text-gray-300">
                    <strong>Thanh Hóa:</strong><br />
                    97 Trịnh Khả, Thanh Hóa
                  </p>
                </div>

                <div className="p-8 rounded-lg bg-slate-800/50 border border-amber-400/20">
                  <Clock className="w-8 h-8 text-amber-400 mb-4" />
                  <h3 className="text-2xl font-bold mb-4">Giờ Mở Cửa</h3>
                  <p className="text-gray-300 mb-2">
                    <strong>Thứ Hai - Chủ Nhật:</strong><br />
                    10:30 AM - 11:00 PM
                  </p>
                  <p className="text-gray-400 text-sm">
                    Đóng cửa vào ngày Lễ Tết theo quy định
                  </p>
                </div>

                <div className="p-8 rounded-lg bg-slate-800/50 border border-amber-400/20">
                  <Phone className="w-8 h-8 text-amber-400 mb-4" />
                  <h3 className="text-2xl font-bold mb-4">Điện Thoại</h3>
                  <p className="text-gray-300">
                    <a href="tel:+84243926789" className="hover:text-amber-400">024 3926 789</a>
                  </p>
                </div>

                <div className="p-8 rounded-lg bg-slate-800/50 border border-amber-400/20">
                  <Mail className="w-8 h-8 text-amber-400 mb-4" />
                  <h3 className="text-2xl font-bold mb-4">Email</h3>
                  <p className="text-gray-300">
                    <a href="mailto:info@masterchef.vn" className="hover:text-amber-400">info@masterchef.vn</a>
                  </p>
                </div>
              </div>

              <div className="p-8 rounded-lg bg-gradient-to-r from-amber-400/10 to-amber-600/10 border border-amber-400/30">
                <Utensils className="w-8 h-8 text-amber-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-4 text-center">Theo Dõi Chúng Tôi</h3>
                <div className="flex justify-center gap-4">
                  <a href="#" className="px-6 py-2 bg-amber-400/20 text-amber-400 rounded hover:bg-amber-400 hover:text-slate-900 transition">
                    Facebook
                  </a>
                  <a href="#" className="px-6 py-2 bg-amber-400/20 text-amber-400 rounded hover:bg-amber-400 hover:text-slate-900 transition">
                    TikTok
                  </a>
                  <a href="#" className="px-6 py-2 bg-amber-400/20 text-amber-400 rounded hover:bg-amber-400 hover:text-slate-900 transition">
                    Instagram
                  </a>
                </div>
              </div>
            </div>
          </section>
        )}
      </div>

      {/* Image Modal */}
      <ImageModal image={selectedImage} onClose={() => setSelectedImage(null)} />

      {/* Footer */}
      <footer className="relative z-10 border-t border-amber-400/20 bg-slate-950/50 py-12 px-4 mt-20">
        <div className="max-w-6xl mx-auto text-center text-gray-400">
          <p>&copy; 2025 Masterchef Restaurant. All rights reserved.</p>
          <p className="text-sm mt-2">Khởi hành hành trình khám phá tinh hoa ẩm thực Việt Nam và thế giới cùng con tàu mang tên Masterchef</p>
        </div>
      </footer>
    </div>
  );
};

export default MasterchefWebsite;
